package com.example.voicedutyassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class WakeWordService : Service(), TextToSpeech.OnInitListener {
    companion object {
        const val ACTION_START = "com.example.voicedutyassistant.START_WAKE"
        private const val CHANNEL_ID = "duty_wake_listener"
        private const val NOTIFICATION_ID = 41
    }
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var isListening = false

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START) {
            val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
            val notification: Notification = builder
                .setContentTitle("Voice Duty Assistant is listening")
                .setContentText("Listening for your custom code and wake words. Tap Stop in the app to turn off.")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
            startForeground(NOTIFICATION_ID, notification)
            beginListening()
        }
        return START_STICKY
    }

    private fun beginListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Speech recognition is unavailable. Please enable Google speech recognition.")
            stopSelf()
            return
        }
        try {
            recognizer?.destroy()
            recognizer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                // Prefer local recognition to reduce network activity and avoid repeated cloud-recognition UI sounds where supported.
                SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
            } else {
                SpeechRecognizer.createSpeechRecognizer(this)
            }
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { isListening = true }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { isListening = false }
                override fun onError(error: Int) { isListening = false; restartSoon() }
                override fun onResults(results: Bundle?) {
                    isListening = false
                    val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    checkWakePhrase(heard)
                    restartSoon()
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            startRecognizer()
        } catch (_: Exception) { restartSoon() }
    }

    private fun startRecognizer() {
        if (isListening) return
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer?.startListening(intent)
            isListening = true
        } catch (_: Exception) { isListening = false; restartSoon() }
    }

    private fun checkWakePhrase(heardText: String) {
        if (heardText.isBlank()) return
        val prefs = getSharedPreferences("duty", MODE_PRIVATE)
        val code = prefs.getString("wake_code", "blue seven").orEmpty().trim().lowercase(Locale.ROOT)
        val words = prefs.getString("wake_words", "hello duty").orEmpty().trim().lowercase(Locale.ROOT)
        val heard = heardText.lowercase(Locale.ROOT)
        if (code.isNotBlank() && words.isNotBlank() && heard.contains(code) && heard.contains(words)) {
            val schedule = prefs.getString("schedule", "").orEmpty()
            speak(if (schedule.isBlank()) "I'm awake. Please open the app and save your duty schedule first." else "I'm awake. Your duty schedule is $schedule")
        }
    }

    private fun restartSoon() {
        android.os.Handler(mainLooper).postDelayed({ if (recognizer != null) startRecognizer() }, 700)
    }

    private fun speak(message: String) {
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "wake_reply")
    }

    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale.US }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Duty wake listening", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
